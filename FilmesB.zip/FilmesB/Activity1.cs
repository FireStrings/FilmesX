﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLitePCL.lib;
using SQLite;
using Android.Util;
using System.IO;

namespace FilmesB
{
    [Activity(Label = "Activity1")]
    public class Activity1 : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            SetContentView(Resource.Layout.layout1);


            //Android.Support.V7.Widget.Toolbar toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar);
            //SetSupportActionBar(toolbar);

            // Create your application here


            Button button1 = FindViewById<Button>(Resource.Id.btCadastrar);
            button1.Click += Button_Click;

            Button button2 = FindViewById<Button>(Resource.Id.btVoltar);
            button2.Click += Button2_Click;
        }


        private void Button2_Click(object sender, EventArgs e)
        {

            StartActivity(typeof(MainActivity));
        }

        private void Button_Click(object sender, EventArgs e)
        {

            string dbPath = Path.Combine(
        System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal),
        "filmes.db3");
            var db = new SQLiteConnection(dbPath);

            db.CreateTable<Models.Filme>();
            var filme = new Models.Filme();

            var etDiretor = FindViewById<EditText>(Resource.Id.etDiretor);
            var etGenero = FindViewById<EditText>(Resource.Id.etGenero);
            var etNome = FindViewById<EditText>(Resource.Id.etNome);


            filme.Diretor = etDiretor.Text;
            filme.Genero = etGenero.Text;
            filme.Nome = etNome.Text;

            db.Insert(filme);

            Context context = Application.Context;
            string text = "Cadastro com sucesso!";
            ToastLength duration = ToastLength.Short;

            var toast = Toast.MakeText(context, text, duration);
            toast.Show();



        }

    }
}