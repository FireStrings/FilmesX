﻿using System;
using SQLite;

namespace Models
{
    public class Filme
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string Nome { get; set; }
        public string Genero{ get; set; }

        public string Diretor { get; set; }


    }
}