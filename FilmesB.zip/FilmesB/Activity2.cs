﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLite;

namespace FilmesB
{
    [Activity(Label = "Activity2")]
    public class Activity2 : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {

            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            SetContentView(Resource.Layout.layout2);

            Button button1 = FindViewById<Button>(Resource.Id.btListar);
            button1.Click += Button_Click;

            Button button2 = FindViewById<Button>(Resource.Id.btVoltar2);
            button2.Click += Button2_Click;
            // Create your application here
        }

        private void Button2_Click(object sender, EventArgs e)
        {

            StartActivity(typeof(MainActivity));
        }

            private void Button_Click(object sender, EventArgs e)
        {
            string dbPath = Path.Combine(
      System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal),
      "filmes.db3");
            var db = new SQLiteConnection(dbPath);

            var stock = db.Query<Models.Filme>("SELECT * FROM Filme");
            System.Diagnostics.Debug.WriteLine("OK");

            var resultado = "";

            foreach (Models.Filme f in stock) {
                resultado = resultado + "Nome: "+ f.Nome + ", Gênero: " + f.Genero + ", " + "Diretor: " + f.Diretor + "\n";
                
            }
            

            var listagem = FindViewById<EditText>(Resource.Id.listagem);
            listagem.Text = resultado;
        }
    }
}